import csv
import jaydebeapi
##The JayDeBeApi module allows you to connect from Python code to databases using Java JDBC. It provides a Python DB-API v2.0 to that database

dsn_database = "DM_SALES"            
dsn_hostname = "xppapl0131-vip.tfs.toyota.com" 
dsn_port = "5480"                
dsn_uid = "nimmags1"        
dsn_pwd = "XXXXXXXXX"      
jdbc_driver_name = "org.netezza.Driver"
jdbc_driver_loc = "C:/JDBC/nzjdbc.jar"

##jdbc_driver_loc = "/Users/nimmags1/Downloads/netezza-3.5.0.jar/"
###jdbc:netezza://" + server + "/" + dbName ;

connection_string='jdbc:netezza://'+dsn_hostname+':'+dsn_port+'/'+dsn_database
url = '{0}:user={1};password={2}'.format(connection_string, dsn_uid, dsn_pwd)
print("URL: " + url)
print("Connection String: " + connection_string)

conn = jaydebeapi.connect("org.netezza.Driver", connection_string, {'user': dsn_uid, 'password': dsn_pwd},
                         jars = "C:/JDBC/nzjdbc.jar")
cursor1 = conn.cursor()
cursor2 = conn.cursor()
cursor1.execute("select distinct name as table_name from _v_relation_column where owner ='ADMIN' and database='DM_SALES' and (ATTNAME = 'DM_MODIFIED_DATE' ) and type <> 'VIEW' and name not like '%BKP%'and nvl(instr(translate(name,'1234567890','1111111111'),'1'),0) =0")
with open("C:/users/nimmags1/Downloads/new_results.csv", "w", newline='') as f:
 data= cursor1.fetchall()
 for i in data:
   #print (i[0])  
   cursor2.execute("select MAX(dm_modified_date), MAX(dm_created_date),(select distinct name From _v_relation_column where name ='" + (str(i[0])) + "' ) from "+ (str(i[0])) + ";")
   data2 =cursor2.fetchall()
   print (data2, file =f)

cursor1.close()
cursor2.close()
conn.close()