import ply.lex as lex, re
import csv
import re
import jaydebeapi
##The JayDeBeApi module allows you to connect from Python code to databases using Java JDBC. It provides a Python DB-API v2.0 to that database

results = []
MAX_ITERATIONS = 5
offset = None

dsn_database = "DM_REMARKETING"            
dsn_hostname = "xtpapl0205-vip.tfs.toyota.com" 
dsn_port = "5480"                
dsn_uid = "nimmags1"        
dsn_pwd = "XXXXX"      
jdbc_driver_name = "org.netezza.Driver"
jdbc_driver_loc = "C:/JDBC/nzjdbc.jar"

##jdbc_driver_loc = "/Users/nimmags1/Downloads/netezza-3.5.0.jar/"
###jdbc:netezza://" + server + "/" + dbName ;

connection_string='jdbc:netezza://'+dsn_hostname+':'+dsn_port+'/'+dsn_database
url = '{0}:user={1};password={2}'.format(connection_string, dsn_uid, dsn_pwd)
print("URL: " + url)
print("Connection String: " + connection_string)

conn = jaydebeapi.connect("org.netezza.Driver", connection_string, {'user': dsn_uid, 'password': dsn_pwd},
                         jars = "C:/JDBC/nzjdbc.jar")
                         
def tables_in_query(sql_str):

    # remove the /* */ comments
    q = re.sub(r"/\*[^*]*\*+(?:[^*/][^*]*\*+)*/", "", sql_str)

    # remove whole line -- and # comments
    lines = [line for line in q.splitlines() if not re.match("^\s*(--|#)", line)]

    # remove trailing -- and # comments
    q = " ".join([re.split("--|#", line)[0] for line in lines])

    # split on blanks, parens and semicolons
    tokens = re.split(r"[\s)(;]+", q)

    # scan the tokens. if we see a FROM or JOIN, we set the get_next
    # flag, and grab the next one (unless it's SELECT).

    result = set()
    get_next = False
    for tok in tokens:
        if get_next:
            if tok.lower() not in ["", "select"]:
                result.add(tok)
            get_next = False
        get_next = tok.lower() in ["from", "join"]

    return result

##DM_USAGE_TEST table has all the query dumps
cursor1 = conn.cursor()
cursor1.execute("SELECT QH_SQL FROM DM_REMARKETING..USER_QUERY_HISTORY_DM_REMARKETING")
##dump all the parsed data into a file
with open("C:/users/nimmags1/Downloads/parsed_results.csv", "w", newline='') as f:
 data= cursor1.fetchall()
 count =0
 for i  in data:
   count= count+1
   #print (i[0])    
   x=tables_in_query(str(i))
   print (x, file =f)
 print ('Count: ', count)

 #cursor1.close()
 
conn.close()